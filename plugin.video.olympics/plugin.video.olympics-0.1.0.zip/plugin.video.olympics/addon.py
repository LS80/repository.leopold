# coding=utf-8
##########################################################################
#
#  Copyright 2016 Lee Smith
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
# 
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
# 
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##########################################################################

import os
import uuid
import subprocess

from xbmcswift2 import Plugin

URL_FMT = "http://a.files.bbci.co.uk/media/live/manifesto/audio_video/webcast/hls/uk/abr_hdtv/ak/sport_stream_{:02d}.m3u8"

plugin = Plugin()


def get_channels():
    for channel in range(1, 25):
        url = URL_FMT.format(channel)
        thumbnail = os.path.join(plugin.storage_path, str(uuid.uuid4())) + '.png'
        if subprocess.call(["ffmpeg", "-y", "-i", url, "-vframes", "1", thumbnail]) == 0:
            yield {'label': "Channel {}".format(channel),
                   'thumbnail': thumbnail,
                   'path': url,
                   'is_playable': True}


@plugin.route('/')
def show_channels():
    return get_channels()


if __name__ == '__main__':
    plugin.run()

