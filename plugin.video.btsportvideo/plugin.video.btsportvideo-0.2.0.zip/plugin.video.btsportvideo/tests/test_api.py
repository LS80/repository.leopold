from datetime import date, timedelta

from resources.lib import api


def test_videos():
    videos, num_pages = list(api.videos(category='ALL', page_size=1))
    assert num_pages > 0
    all_videos = list(videos)
    assert len(all_videos) == 1
    video = all_videos[0]
    assert video.title
    assert video.thumbnail
    assert video.url
    assert video.date > date.today() - timedelta(days=365)
    assert 0 < video.duration < 3600


def test_search_results():
    videos, num_pages = list(api.search_results(term='test cricket', page_size=1))
    assert num_pages > 0
    all_videos = list(videos)
    assert len(all_videos) == 1
    video = all_videos[0]
    assert video.title
    assert video.thumbnail
    assert video.url
    assert video.date > date.today() - timedelta(days=365)
    assert 0 < video.duration < 3600


def test_categories():
    categories = list(api.categories())
    assert len(categories) > 5
    assert 'Football' in categories
    assert 'Cricket' in categories
