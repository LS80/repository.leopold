import json
import re

import requests
from bs4 import BeautifulSoup

R = re.compile("kWidget.embed\((.*?)\)", re.MULTILINE|re.DOTALL)

def get_stadium_cams():
    soup = BeautifulSoup(requests.get("http://www.tottenhamhotspur.com/new-scheme/stadium-tv/").text, 'html.parser')
    for video in soup('div', 'video-new'):
        title = video.find_previous('h2').get_text()
        print video('script')[-1].string
        entry_id = json.loads(R.search(video('script')[-1].string).group(1))['entry_id']
        print entry_id
        print title
        yield title, entry_id


print list(get_stadium_cams())


