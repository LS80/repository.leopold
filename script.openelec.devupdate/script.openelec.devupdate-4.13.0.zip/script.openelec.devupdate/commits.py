from bs4 import BeautifulSoup
import requests
import codecs
import html2text

commits = BeautifulSoup(requests.get("https://github.com/xbmc/xbmc/commits/f3c46e0").text).find('div', 'commits-listing')

h = html2text.HTML2Text()
h.ignore_links = True
text = h.handle(unicode(commits))

codecs.open('commits.txt', 'w', 'utf-8').write(text)

