import os

import addon

UPDATE_EXTLINUX_FILE = os.path.join(addon.data_path, 'update_extlinux')
NOTIFY_FILE = os.path.join(addon.data_path, 'installed_build')
