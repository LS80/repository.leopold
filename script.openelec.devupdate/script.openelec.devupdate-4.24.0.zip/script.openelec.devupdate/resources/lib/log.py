import sys
import functools

import xbmc, xbmcaddon, xbmcgui

import constants


addon = xbmcaddon.Addon(constants.ADDON_ID)

ADDON_NAME = addon.getAddonInfo('name')
ADDON_VERSION = xbmc.translatePath(addon.getAddonInfo('version'))


def log(txt, level=xbmc.LOGDEBUG):
    if not (addon.getSetting('debug') == 'false' and level == xbmc.LOGDEBUG):
        msg = '{} v{}: {}'.format(ADDON_NAME, ADDON_VERSION, txt)
        xbmc.log(msg, level)


log_error = functools.partial(log, level=xbmc.LOGERROR)


def log_exception():
    import traceback
    log("".join(traceback.format_exception(*sys.exc_info())), xbmc.LOGERROR)


def logging(msg_success=None, msg_error=None, log_exc=True):
    def wrap(func):
        @functools.wraps(func)
        def call_with_logging(*args, **kwargs):
            try:
                result = func(*args, **kwargs)
            except:
                if msg_error is not None:
                    log_error(msg_error.format(*args))
                if log_exc:
                    log_exception()
            else:
                if msg_success is not None:
                    log(msg_success.format(*args))
                return result
        return call_with_logging
    return wrap
