import json
import base64
from datetime import datetime

def expiry(jwt):
    payload_base64 = (jwt.split('.')[1] + '==').encode('ascii')
    return datetime.fromtimestamp(json.loads(base64.b64decode(payload_base64))['exp'])
