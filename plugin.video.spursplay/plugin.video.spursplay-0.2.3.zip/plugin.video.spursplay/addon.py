import base64
import json
import sys
from datetime import datetime
from urllib.parse import parse_qsl

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import resources.lib.spursplay as spursplay

# Get the plugin url in plugin:// notation.
__url__ = sys.argv[0]
# Get the plugin handle as an integer number.
__handle__ = int(sys.argv[1])


api = spursplay.Api()


def router(paramstring):
    params = dict(parse_qsl(paramstring[1:]))
    if params:
        if params["action"] == "play":
            play_video(params["id"], "live" in params)
        elif params["action"] == "listing":
            list_videos(params["id"], params.get("lastSeen"))
        elif params["action"] == "playlists":
            list_playlists(params["id"], params.get("lastSeen"))
        elif params["action"] == "playlist-listing":
            list_playlist_videos(params["id"], params.get("page"))
        elif params["action"] == "section":
            list_section(params["name"])
    else:
        list_categories()


def token_expiry(jwt):
    payload_base64 = (jwt.split(".")[1] + "==").encode("ascii")
    return datetime.fromtimestamp(json.loads(base64.b64decode(payload_base64))["exp"])


def login():
    settings = xbmcaddon.Addon().getSettings()

    email, password = settings.getString(id="email"), settings.getString(id="password")
    token = settings.getString(id="token")

    if email and password and (not token or datetime.now() > token_expiry(token)):
        xbmc.log("Logging in", level=xbmc.LOGDEBUG)
        try:
            token = api.login(email, password)
        except spursplay.LoginError as exc:
            dialog = xbmcgui.Dialog()
            dialog.notification("SPURSPLAY", str(exc), xbmcgui.NOTIFICATION_ERROR)
        else:
            settings.setString("token", token)


def list_categories():
    events = api.get_live_events()
    listing = list(_video_items(events, live=True))

    buckets = api.buckets(section="First Team", num_pages=2)
    for name, category_id in buckets:
        list_item = xbmcgui.ListItem(label=name)
        url = f"{__url__}?action=listing&id={category_id}"
        listing.append((url, list_item, True))

    playlists = api.playlists()
    for name, category_id in playlists:
        list_item = xbmcgui.ListItem(label=name)
        url = f"{__url__}?action=playlists&id={category_id}"
        listing.append((url, list_item, True))

    for section in ["Academy", "Players"]:
        list_item = xbmcgui.ListItem(label=section)
        url = f"{__url__}?action=section&name={section}"
        listing.append((url, list_item, True))

    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)


def list_section(section):
    listing = []
    buckets = api.buckets(section)
    for name, category_id in buckets:
        xbmc.log(name, level=xbmc.LOGDEBUG)
        list_item = xbmcgui.ListItem(label=name)
        url = f"{__url__}?action=listing&id={category_id}"
        listing.append((url, list_item, True))

    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)


def list_playlists(category_id, last_seen=None):
    playlists, new_last_seen, more_available = api.get_bucket_playlists(category_id, last_seen)
    listing = []
    for playlist in playlists:
        list_item = xbmcgui.ListItem(label=playlist["title"])
        thumb = playlist["thumbnail"]
        list_item.setArt({"icon": thumb, "thumb": thumb})
        list_item.setProperty("fanart_image", thumb)
        url = f"{__url__}?action=playlist-listing&id={playlist['id']}"
        listing.append((url, list_item, True))

    if more_available:
        list_item = xbmcgui.ListItem(label="Show More")
        url = f"{__url__}?action=playlists&id={category_id}&lastSeen={new_last_seen}"
        listing.append((url, list_item, True))

    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__, updateListing=last_seen is not None)


def _video_items(videos, live=False):
    for video in videos:
        list_item = xbmcgui.ListItem(label=video["title"])
        thumb = video["thumbnail"]
        list_item.setArt({"icon": thumb, "thumb": thumb})
        list_item.setProperty("fanart_image", thumb)
        list_item.setProperty("IsPlayable", "true")
        video_info = list_item.getVideoInfoTag()
        video_info.setTitle(video["title"])
        if video["duration"] is not None:
            video_info.setDuration(video["duration"])
        url = f"{__url__}?action=play&id={video['id']}" + "&live" * live
        yield (url, list_item, False)


def list_playlist_videos(playlist_id, page=None):
    videos, more_available = api.get_playlist_videos(playlist_id, page)

    listing = list(_video_items(videos))

    if more_available:
        list_item = xbmcgui.ListItem(label="Show More")
        url = f"{__url__}?action=playlist-listing&id={playlist_id}&page={int(page or 1)+1}"
        listing.append((url, list_item, True))

    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__, updateListing=page is not None)


def list_videos(category_id="J34p", last_seen=None):
    videos, new_last_seen, more_available = api.get_bucket_videos(category_id, last_seen)

    listing = list(_video_items(videos))

    if more_available:
        list_item = xbmcgui.ListItem(label="Show More")
        url = f"{__url__}?action=listing&id={category_id}&lastSeen={new_last_seen}"
        listing.append((url, list_item, True))

    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__, updateListing=last_seen is not None)


def play_video(video_id, live):
    url = api.get_video_url(video_id, live)
    play_item = xbmcgui.ListItem(path=url)

    xbmcplugin.setResolvedUrl(__handle__, True, listitem=play_item)


if __name__ == "__main__":
    login()
    router(sys.argv[2])
