from __future__ import division

import xbmc, xbmcgui

class Progress(xbmcgui.DialogProgress):

    def __init__(self, heading):
        xbmcgui.DialogProgress.__init__(self)
        self.create(heading)
 
    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        self.close()

    def start(self):
        for i in range(100):
            self.update(i, "{0}/100".format(i))
            xbmc.sleep(50)


with Progress("Progress Bar 1") as progress:
    progress.start()
      
with Progress("Progress Bar 2") as progress:
    progress.start()
        
xbmc.executebuiltin("Notification(Progress Problem, You should have seen two progress bars)")

    

 
