from . import libreelec


def mock_libreelec():
    libreelec.OS_RELEASE['NAME'] = 'LibreELEC'
    libreelec.OS_RELEASE['VERSION_ID'] = '9.2'
    libreelec.OS_RELEASE['VERSION'] = 'Milhouse-20200626135925-#0626-gcc6e86c'
    libreelec.OS_RELEASE['MILHOUSE_BUILD'] = '200626'
    libreelec.OS_RELEASE['LIBREELEC_ARCH'] = 'RPi4.arm'
