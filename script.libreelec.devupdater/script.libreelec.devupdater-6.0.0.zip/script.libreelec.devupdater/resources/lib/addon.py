import os
import xbmcvfs
import xbmcaddon

__addon = xbmcaddon.Addon('script.libreelec.devupdater')

info = __addon.getAddonInfo
get_setting = __addon.getSetting
set_setting = __addon.setSetting
open_settings = __addon.openSettings
L10n = __addon.getLocalizedString


def get_bool_setting(setting):
    return __addon.getSettingBool(setting)


def get_int_setting(setting):
    return __addon.getSettingInt(setting)


name = info('name')
version = info('version')
data_path = xbmcvfs.translatePath(info('profile'))
src_path = xbmcvfs.translatePath(info('path'))
icon_path = info('icon')
notification_icon_path = os.path.join(src_path, 'notification.png')
