import time

import xbmc
import xbmcgui
import xbmcaddon

import utils
from log import *

__addon__ = xbmcaddon.Addon("script.foscam")
__path__ = xbmc.translatePath(__addon__.getAddonInfo('path'))

class Button(xbmcgui.ControlButton):
    WIDTH = HEIGHT = 32

    def __new__(cls, parent, action, x, y, scaling=1.0):
        focusTexture = utils.TEXTURE_FMT.format(action + '-focus')
        noFocusTexture = utils.TEXTURE_FMT.format(action)
        width = int(round(cls.WIDTH * scaling))
        height = int(round(cls.HEIGHT * scaling))
        self = super(Button, cls).__new__(cls, x, y, width, height, "", focusTexture, noFocusTexture)

        parent.buttons.append(self)
        return self


class ToggleButton(xbmcgui.ControlRadioButton):
    WIDTH = 110
    HEIGHT = 40

    def __new__(cls, parent, action, x, y):
        focusOnTexture = utils.TEXTURE_FMT.format('radio-on')
        noFocusOnTexture = utils.TEXTURE_FMT.format('radio-on')
        focusOffTexture = utils.TEXTURE_FMT.format('radio-off')
        noFocusOffTexture = utils.TEXTURE_FMT.format('radio-off')
        focusTexture = utils.TEXTURE_FMT.format('back')
        noFocusTexture = utils.TEXTURE_FMT.format('trans')
        textOffsetX = 12

        self = super(ToggleButton, cls).__new__(cls, x, y, cls.WIDTH, cls.HEIGHT, action.title(),
                                                focusOnTexture, noFocusOnTexture,
                                                focusOffTexture, noFocusOffTexture,
                                                focusTexture, noFocusTexture,
                                                textOffsetX)

        self.action = action
        
        parent.buttons.append(self)
        return self

    def send_cmd(self, control):
        return self.cmd.set_enabled(control.isSelected())

class CameraPreviewXML(xbmcgui.WindowXMLDialog):
    def __new__(cls, duration, path, scaling, position, mjpeg_stream):
        return super(CameraPreviewXML, cls).__new__(cls, "CameraPreview.xml", __path__)
    
    def __init__(self, duration, path, scaling, position, mjpeg_stream):
        log_normal("Showing preview")

        self.duration = duration
        self.path = path
        self.scaling = scaling
        self.position = position
        self.mjpeg_stream = mjpeg_stream
        
       # window = xbmcgui.Window(xbmcgui.getCurrentWindowDialogId())
        #window.setProperty('SlideDirection', self.position.split()[1])
        #self.imagegroup = self.getControl(10)
        
    def onInit(self):
        WIDTH = 480
        HEIGHT = 270
        width = int(WIDTH * self.scaling)
        height = int(HEIGHT * self.scaling)

        if "bottom" in self.position:
            y = 1080 - height
        else:
            y = 0

        if "left" in self.position:
            x = 0
            start = -1920
        else:
            x = 1920 - width
            start = 1920
        
        animations = [('Conditional',
                       "effect=slide start={0:d} time=2000 tween=cubic easing=out condition=true".format(start)),
                      ('WindowClose',
                       "effect=slide end={0:d} time=2000 tween=cubic easing=in".format(start))]
        
        window = xbmcgui.Window(xbmcgui.getCurrentWindowDialogId())
        window.setProperty('SlideDirection', self.position.split()[1])

        self.imagegroup = self.getControl(10)
        self.imagegroup.setAnimations(animations)
        self.imagegroup.setPosition(x,y)
        self.imagegroup.setHeight(height)
        self.imagegroup.setWidth(width)
        
        self.image1 = self.getControl(100)
        self.image1.setHeight(height)
        self.image1.setWidth(width)
  
        self.image2 = self.getControl(200)
        self.image2.setHeight(height)
        self.image2.setWidth(width)
        
    def set_images(self, filename):
        #pass
        self.image1.setImage(filename, False)
        self.image2.setImage(filename, False)
    
    def start(self):
        with utils.ExtractMJPEGFrames(self.path, self.duration, self.mjpeg_stream,
                                      self.set_images) as self.extract_mjpeg:
            duration = self.extract_mjpeg.start()
        return duration
    
    def onAction(self, action):
        if action in (utils.ACTION_PREVIOUS_MENU, utils.ACTION_BACKSPACE, utils.ACTION_NAV_BACK):
            self.stop()
            
    def stop(self):
        log_normal("Closing preview")
        self.close()
        self.extract_mjpeg.stop()


class CameraPreview(xbmcgui.WindowDialog):
    def __init__(self, duration, path, scaling, position, mjpeg_stream):
        log_normal("Showing preview")
        
        self.buttons = []

        self.duration = duration
        self.path = path
        self.mjpeg_stream = mjpeg_stream
        
        self.setProperty('zorder', "999")
        
        WIDTH = 320
        HEIGHT = 180

        width = int(WIDTH * scaling)
        height = int(HEIGHT * scaling)

        if "bottom" in position:
            y = 720 - height
        else:
            y = 0

        if "left" in position:
            x = 0
            start = - width
        else:
            x = 1280 - width
            start = width

        animations = [('WindowOpen',
                       "effect=slide start={0:d} time=2000 tween=cubic easing=out".format(start)),
                      ('WindowClose',
                       "effect=slide end={0:d} time=2000 tween=cubic easing=in".format(start))]
        
        self.animations = [('Conditional',
                       "effect=slide start={0:d} time=2000 tween=cubic easing=out condition=true".format(start))]
        
        

        self.image = xbmcgui.ControlImage(x, y, width, height, utils.TEXTURE_FMT.format('black'))
        self.addControl(self.image)
        #self.image.setVisible(False)
        self.image.setAnimations([('Conditional', "effect=fade start=0 end=20 delay=2000 time=0 condition=true",)])
        #self.image.setAnimations(animations)  
        
        self.image2 = xbmcgui.ControlImage(x, y, width, height, utils.TEXTURE_FMT.format('black'))
        self.addControl(self.image2)
        self.image2.setAnimations([('Conditional',
                       "effect=slide start={0:d} time=2000 tween=cubic easing=out condition=true".format(start))])
        #self.image2.setVisible(True)
        
            
        trans = utils.TEXTURE_FMT.format('trans')
        self.select_button = xbmcgui.ControlButton(x, y, width, height, "", trans, trans)
        self.addControl(self.select_button)
        self.select_button.setVisible(False)
        #self.select_button.setAnimations(animations)

        button_scaling = 0.5 * scaling
        button_width = int(round(Button.WIDTH * button_scaling))
        self.close_button = Button(self, 'close', x + width - button_width - 10, y + 10, scaling=button_scaling)
        self.addControl(self.close_button)
        self.close_button.setVisible(False)
        #self.close_button.setAnimations(animations)

    def start(self):
        self.image2.setAnimations(self.animations) 
        with utils.ExtractMJPEGFrames(self.path, self.duration, self.mjpeg_stream,
                                      self.set_images) as self.extract_mjpeg:
            duration = self.extract_mjpeg.start()
        return duration

    def onControl(self, control):
        if control == self.close_button:
            self.stop()
        elif control == self.select_button:
            self.run()
            
    def onAction(self, action):
        if action in (utils.ACTION_PREVIOUS_MENU, utils.ACTION_BACKSPACE, utils.ACTION_NAV_BACK):
            self.stop()
        elif action == utils.ACTION_SELECT_ITEM:
            self.run()
            
    def set_images(self, filename):
        self.image.setImage(filename, False)
        self.image2.setImage(filename, False)
            
    def run(self):
        xbmc.executebuiltin("RunAddon({0})".format(utils.addon_info('id')))
        self.stop()
            
    def stop(self):
        log_normal("Closing preview")
        #self.close_button.setVisible(False)
        self.extract_mjpeg.stop()
        self.close()

